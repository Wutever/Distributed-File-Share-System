package craneNimbus

var isHotStandby = true


func inStream()  {
	
}
func distributeStream()  {

}

// return a list of live nodes
func getCurrentAliveNode() []int{
	return []int{0}
}

// return a list of current idle node, ready for job distribution
func getCurrentIdleNode() [] int{
	return []int{0}
}




